/** Automatically generated file. DO NOT MODIFY */
package ca.demo.databasetolistviewdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}